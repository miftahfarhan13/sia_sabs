<?php $__env->startSection('content'); ?>
<html>

<head>
    <title>Hasil Penilaian Akademik</title>
</head>

<body>
    <div>
        <h2 class="font-weight-bold">Hasil Penilaian Akademik</h2>
        <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>

        <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>

        <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>

        <?php if($message = Session::get('info')): ?>
        <div class="alert alert-info alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert">×</button>
            Please check the form below for errors
        </div>
        <?php endif; ?>
        <div class="form-group row">
            <label class="col-form-label font-weight-bold col-sm-2">Tahun Ajaran</label>
            <div class="col-sm-10">
                <?php $__currentLoopData = $tahunajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahunajarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="col-form-label"><?php echo e($tahunajarans->tahun_ajaran); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <label class="col-sm-2 col-form-label font-weight-bold">Semester</label>
            <div class="col-sm-10">
                <?php $__currentLoopData = $tahunajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahunajaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="col-form-label"><?php echo e($tahunajarans->semester); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div class="form-row mt-3">
            <div class="col">
                <ul class="nav nav-tabs" id="myTabPendaftaran" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="materi-tab" data-toggle="tab" href="#penilaianMateri" role="tab"
                            aria-controls="Penilaian Materi" aria-selected="true">Penilaian Materi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="sikap-tab" data-toggle="tab" href="#penilaianSikap" role="tab"
                            aria-controls="Penilaian Sikap" aria-selected="false">Penilaian Sikap</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="keterampilan-tab" data-toggle="tab" href="#penilaianKeterampilan"
                            role="tab" aria-controls="Penilaian Keterampilan" aria-selected="false">Penilaian
                            Keterampilan</a>
                    </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="penilaianMateri" role="tabpanel"
                        aria-labelledby="materi-tab">
                        <div class="mt-2">
                            <div class="card">
                                <div class="card-header">Penilaian Materi</div>
                                <div class="card-body">
                                    <label class="col-form-label" id="kategori_pengetahuan" hidden>Pengetahuan</label>
                                    <table class="table" id="data_table">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Kode Mapel</th>
                                                <th scope="col">Mata Pelajaran</th>
                                                <th scope="col">Kelas</th>
                                                <th scope="col">Nama Guru</th>
                                                <th scope="col">Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $matapelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $matapelajarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($index+1); ?></th>
                                                <td><label id="nama_kelas"><?php echo e($matapelajarans->kode_mapel); ?></label>
                                                </td>
                                                <td><?php echo e($matapelajarans->nama_mata_pelajaran); ?></td>
                                                <td><?php echo e($matapelajarans->nama_kelas); ?></td>
                                                <td><?php echo e($matapelajarans->nama_guru_sekolah); ?></td>
                                                <td><button type="button"
                                                        class="btn btn-primary tombolDetailNilaiPengetahuan"
                                                        id="<?php echo e(Auth::user()->id_user); ?>"
                                                        data-id="<?php echo e(Auth::user()->id_user); ?>"
                                                        data-idguru="<?php echo e($matapelajarans->id_user); ?>"
                                                        value="<?php echo e(Auth::user()->id_user); ?>"> Lihat</button>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="penilaianSikap" role="tabpanel" aria-labelledby="sikap-tab">
                        <div class="mt-2">
                            <div class="card">
                                <div class="card-header">Penilaian Sikap</div>
                                <div class="card-body">
                                    <label class="col-form-label" id="kategori_sikap" hidden>Sikap</label>
                                    <table class="table" id="data_table">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Kode Mapel</th>
                                                <th scope="col">Mata Pelajaran</th>
                                                <th scope="col">Kelas</th>
                                                <th scope="col">Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $matapelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $matapelajarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($index+1); ?></th>
                                                <td><label id="nama_kelas"><?php echo e($matapelajarans->kode_mapel); ?></label>
                                                </td>
                                                <td><?php echo e($matapelajarans->nama_mata_pelajaran); ?></td>
                                                <td><?php echo e($matapelajarans->nama_kelas); ?></td>
                                                <td><button type="button" class="btn btn-primary tombolDetailNilaiSikap"
                                                        id="<?php echo e(Auth::user()->id_user); ?>"
                                                        data-id="<?php echo e(Auth::user()->id_user); ?>"
                                                        value="<?php echo e(Auth::user()->id_user); ?>"> Lihat</button>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="penilaianKeterampilan" role="tabpanel"
                        aria-labelledby="keterampilan-tab">
                        <div class="mt-2">
                            <div class="card">
                                <div class="card-header">Penilaian Keterampilan</div>
                                <div class="card-body">
                                    <label class="col-form-label" id="kategori_keterampilan" hidden>Keterampilan</label>
                                    <table class="table" id="data_table">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Kode Mapel</th>
                                                <th scope="col">Mata Pelajaran</th>
                                                <th scope="col">Kelas</th>
                                                <th scope="col">Detail</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $matapelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $matapelajarans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($index+1); ?></th>
                                                <td><label id="nama_kelas"><?php echo e($matapelajarans->kode_mapel); ?></label>
                                                </td>
                                                <td><?php echo e($matapelajarans->nama_mata_pelajaran); ?></td>
                                                <td><?php echo e($matapelajarans->nama_kelas); ?></td>
                                                <td><button type="button"
                                                        class="btn btn-primary tombolDetailNilaiKeterampilan"
                                                        id="<?php echo e(Auth::user()->id_user); ?>"
                                                        data-id="<?php echo e(Auth::user()->id_user); ?>"
                                                        value="<?php echo e(Auth::user()->id_user); ?>"> Lihat</button>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="modalDetailNilaiPengetahuan" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nilai</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="form-row">
                            <div class="col">
                                <div class="card">
                                    <div class="card-header">
                                        Hasil Penilaian
                                    </div>
                                    <div class="card-body">
                                        <table class="table" id="modal_nilai_pengetahuan">
                                            <thead>
                                                <tr>
                                                    <th scope="col">No</th>
                                                    <th scope="col">Tipe</th>
                                                    <th scope="col">Nilai</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <div class="card mt-2">
                                    <div class="card-header">
                                        Deskripsi Nilai
                                    </div>
                                    <div class="card-body">
                                        <div class="form-group row">
                                            <textarea class="col-sm form-control rounded-0" id="deskripsi_pengetahuan"
                                                name="deskripsi_pengetahuan" placeholder="Deskripsi raport siswa"
                                                value="" rows="3" readonly></textarea>
                                            <!-- <label class="ml-3 col-form-label" id="deskripsi_pengetahuan"></label> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalDetailNilaiSikap" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nilai</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div style="max-width:1000px">
                            <div class="form-row">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table" id="modal_nilai_sikap">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">No</th>
                                                        <th scope="col">Tipe</th>
                                                        <th scope="col">Nilai</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="card mt-2">
                                        <div class="card-header">
                                            Deskripsi Nilai
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <textarea class="col-sm form-control rounded-0" id="deskripsi_sikap"
                                                    name="deskripsi_sikap" placeholder="Deskripsi raport siswa" value=""
                                                    rows="3" readonly></textarea>
                                                <!-- <label class="ml-3 col-form-label" id="deskripsi_pengetahuan"></label> -->
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="modalDetailNilaiKeterampilan" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">

                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nilai</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div style="max-width:1000px">
                            <div class="form-row">
                                <div class="col">
                                    <div class="card">
                                        <div class="card-body">
                                            <table class="table" id="modal_nilai_keterampilan">
                                                <thead>
                                                    <tr>
                                                        <th scope="col">No</th>
                                                        <th scope="col">Tipe</th>
                                                        <th scope="col">Nilai</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                </tbody>
                                                <tfoot>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>

                                    <div class="card mt-2">
                                        <div class="card-header">
                                            Deskripsi Nilai
                                        </div>
                                        <div class="card-body">
                                            <div class="form-group row">
                                                <textarea class="col-sm form-control rounded-0"
                                                    id="deskripsi_keterampilan" name="deskripsi_keterampilan"
                                                    placeholder="Deskripsi raport siswa" value="" rows="3"
                                                    readonly></textarea>
                                                <!-- <label class="ml-3 col-form-label" id="deskripsi_pengetahuan"></label> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<script>
    $(document).ready(function () {
        $(document).on('click', '.tombolDetailNilaiPengetahuan', function () {
            $("textarea#deskripsi_pengetahuan").val('');
            // $('#modalEditNilai').modal('show');
            var id = $(this).data('id');
            var idguru = $(this).data('idguru');
            var idmatapelajaran = $(this).closest('tr').find('label').html();
            $.ajax({
                url: "/getNilaiMataPelajaranOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': idmatapelajaran,
                    'id_kategori': $('#kategori_pengetahuan').html(),
                    'id_gurusekolah': idguru,
                },
                dataType: 'json',
                success: function (data) {
                    var no_tabel = 0;
                    var markup = '';
                    $.each(data, function (key, value) {
                        no_tabel++;
                        markup += '<tr> <td> ' + no_tabel +
                            ' </td> <td> ' +
                            value.tipe_nilai +
                            ' </td><td>' + value.nilai +
                            '</td></tr>';
                    });
                    $('#modal_nilai_pengetahuan tbody').html(markup);

                }
            });

            $.ajax({
                url: "/getDeskripsiMataPelajaranOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': idmatapelajaran,
                    'id_kategori': 'Pengetahuan',
                },
                dataType: 'json',
                success: function (data) {

                    $.each(data, function (key, value) {
                        $("textarea#deskripsi_pengetahuan").val(value.nilai);
                    });


                }
            });

            $('#modalDetailNilaiPengetahuan').modal('show');

        });

        $(document).on('click', '.tombolDetailNilaiSikap', function () {
            // $('#modalEditNilai').modal('show');
            var id = $(this).data('id');
            $("textarea#deskripsi_sikap").val('');
            var idmatapelajaran = $(this).closest('tr').find('label').html();
            $.ajax({
                url: "/getNilaiMataPelajaranSikapOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': $(this).closest('tr').find('label').html(),

                },
                dataType: 'json',
                success: function (data) {

                    var markup = '';
                    var no_tabel = 0;

                    $.each(data, function (key, value) {
                        no_tabel++;
                        markup += '<tr> <td> ' + no_tabel +
                            ' </td> <td> ' +
                            value.tipe_nilai +
                            ' </td><td>' + value.nilai +
                            '</td></tr>';


                    });
                    $('#modal_nilai_sikap tbody').html(markup);
                }
            });

            $.ajax({
                url: "/getDeskripsiMataPelajaranOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': idmatapelajaran,
                    'id_kategori': 'Sikap',
                },
                dataType: 'json',
                success: function (data) {

                    $.each(data, function (key, value) {
                        $("textarea#deskripsi_sikap").val(value.nilai);
                    });
                }
            });

            $('#modalDetailNilaiSikap').modal('show');
        });

        $(document).on('click', '.tombolDetailNilaiKeterampilan', function () {
            // $('#modalEditNilai').modal('show');
            $("textarea#deskripsi_keterampilan").val('');
            var id = $(this).data('id');
            var idmatapelajaran = $(this).closest('tr').find('label').html();
            $.ajax({
                url: "/getNilaiMataPelajaranKeterampilanOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': $(this).closest('tr').find('label').html(),

                },
                dataType: 'json',
                success: function (data) {

                    var markup = '';
                    var no_tabel = 0;

                    $.each(data, function (key, value) {
                        no_tabel++;
                        markup += '<tr> <td> ' + no_tabel +
                            ' </td> <td> ' +
                            value.tipe_nilai +
                            ' </td><td> ' +
                            value.nilai +
                            ' </td></tr>';
                    });
                    $('#modal_nilai_keterampilan tbody').html(markup);

                }
            });

            $.ajax({
                url: "/getDeskripsiMataPelajaranOrangTua",
                type: "get",
                data: {
                    'id_mata_pelajaran': idmatapelajaran,
                    'id_kategori': 'Keterampilan',
                },
                dataType: 'json',
                success: function (data) {
                    $.each(data, function (key, value) {
                        $("textarea#deskripsi_keterampilan").val(value.nilai);
                    });
                }
            });
            $('#modalDetailNilaiKeterampilan').modal('show');
        });

        


    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/hasil_penilaianAkademikOrangTua.blade.php ENDPATH**/ ?>