<?php $__env->startSection('content'); ?>
<div>
    <h2 class="font-weight-bold">Kelola Tahun Ajaran</h2>
    <div class="row  mt-2">
        <div class="col-md-8">
            <div class="mt-2">
                <div class="card">
                    <div class="card-header font-weight-bold">Tambah Tahun Ajaran <button id="simpanDataOrangTua"
                            type="button" class="btn btn-primary simpanDataOrangTua"
                            style="float:right;">Simpan</button></div>

                    <div class="card-body">
                        <div class="alert alert-primary col-sm-12" role="alert">
                            Silahkan isi data tahun ajaran dengan format : ex. 2019/2020
                        </div>
                        <input type="text" class="form-control" id="role_orangtua" name="role_orangtua"
                            value="Orang Tua" hidden>
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label font-weight-bold">Tahun Ajaran</label>
                            <div class="col-sm-3">
                                <input type="text" class="form-control" id="id_orangtua" name="id_orangtua"
                                    placeholder="Isi tahun ajaran">
                            </div>
                            <label class="col-sm-2 col-form-label font-weight-bold">Semester</label>
                            <div class="col-sm-3">
                                <select class="custom-select" id="semester"
                                    name="semester">
                                    <option selected disabled>Pilih Semester</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                </select>
                            </div>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <div style="max-width:500px">
        <div class="form-row mt-3">


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/kelola_tahun_ajaran.blade.php ENDPATH**/ ?>