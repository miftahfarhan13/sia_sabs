<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-weight-bold">Tambah Presensi Asrama</h2>
    <div class="form-group row">

        <label class="col-sm-2 col-form-label font-weight-bold">Tanggal</label>
        <div class="col-sm-10">

            <label class="col-form-label"><?php $tgl=date('l, d-m-Y'); echo $tgl;?></label>

        </div>

    </div>

    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="presensi" role="tabpanel" aria-labelledby="materi-tab">
            <div class="mt-2">
            <div style="max-width:800px">
                <div class="card">
                    <div class="card-header font-weight-bold">Tambah Presensi Siswa</div>

                    <div class="card-body">
                        <table id="presensi_sekolah" class="table data-table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">NIS</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Gedung</th>
                                    <th scope="col">Kelas</th>
                                    <th scope="col">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 0;
                                foreach ($siswaasrama as $index => $siswaasramas):?>
                                <tr>
                                    <th scope="row"><?php echo e($index+1); ?></th>
                                    <th scope="row" hidden><?php echo e($id_kegiatan); ?></th>
                                    <td><?php echo e($siswaasramas->id_siswa); ?></td>
                                    <td><?php echo e($siswaasramas->nama_siswa); ?></td>
                                    <td><?php echo e($siswaasramas->nama_gedung); ?></td>
                                    <td><?php echo e($siswaasramas->nama_kelas_asrama); ?></td>
                                    <td><label class="radio-inline mr-2"><input class="mr-1" type="radio"
                                                name="condition + <?php print $i; ?>" value="Hadir">Hadir</label>
                                        <label class="radio-inline mr-2"><input class="mr-1" type="radio"
                                                name="condition + <?php print $i; ?>" value="Sakit">Sakit</label>
                                        <label class="radio-inline mr-2"><input class="mr-1" type="radio"
                                                name="condition + <?php print $i; ?>" value="Izin">Izin</label>
                                        <label class="radio-inline "><input class="mr-1" type="radio"
                                                name="condition + <?php print $i; ?>" value="Alpha">Alpha</label></td>
                                </tr>
                                <?php $i++; 
                                endforeach; ?>


                            </tbody>
                        </table>
                        <button type="button" class="btn btn-primary tombolUpdatePresensi float-right" id="" data-id=""
                            value="">Simpan</button>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>

</div>
<script>
    $(document).ready(function () {

        $(document).on('click', '.tombolSavePresensi', function () {
            var id = $('#id_kegiatan').closest('tr').find('label').html();
            var idsiswa = $('#id_siswa').val();
            $.ajax({
                url: "/simpanPresensiAsrama",
                type: "post",
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: {
                    'id_user_siswa': idsiswa,
                    'id_kegiatan': id,
                    'keterangan': $(this).closest('tr').find('input,select').val(),
                },
                success: function (data) {
                    alert('Berhasil menyimpan presensi');
                }
            });
        });

        $(document).on('click', '.tombolTambahPresensi', function () {
            // $('#modalEditNilai').modal('show');
            // $('#modalTambahPresensi').modal('show');
            var id = $(this).data('id');
            var nama_kelas = $('#nama_kelas').closest('tr').find('label').html();
            $('#id_siswa').val(id);
            $.ajax({
                url: "/get_kegiatan/" + nama_kelas,
                type: "get",
                data: {
                    'id_user_siswa': id,
                },
                dataType: 'json',
                success: function (data) {

                    var markup = '';
                    var no_tabel = 0;

                    $.each(data, function (key, value) {
                        //dibawah sini ajaxnya
                        no_tabel++;
                        markup +=
                            '<tr> <td> <label class="" id="id_kegiatan" >' +
                            value.id_kegiatan +
                            '</label> ' + no_tabel +
                            ' </td> <td> ' + value
                            .tanggal +
                            ' </td>  <td> ' + value
                            .hari +
                            ' </td>  <td> ' + value
                            .jam +
                            ' </td>  <td> ' + value
                            .nama_kegiatan +
                            ' </td>  <td> ' + value
                            .nama_tempat +
                            ' </td> <td><select class="custom-select" id="keterangan" name=""><option selected disabled>Pilih Keterangan</option><option value="Hadir">Hadir</option><option value="Sakit">Sakit</option><option value="Izin">Izin</option><option value="Alpha">Alpha</option></select></td><td><button type="button" class="btn btn-primary tombolSavePresensi" id="' +
                            value.id + '" data-id="' + value.id + '" value="' +
                            value.id +
                            '"> Simpan</button><button type="button" class="btn btn-primary tombolUpdatePresensi" hidden id="' +
                            value.id + '" data-id="' + value.id + '" value="' +
                            value.id +
                            '"> Update</button></tr>';

                    });

                    $('#modal_presensi tbody').html(markup);
                    $('#modalTambahPresensi').modal('show');
                }
            });
        });
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/tambah_data_presensi_asrama.blade.php ENDPATH**/ ?>