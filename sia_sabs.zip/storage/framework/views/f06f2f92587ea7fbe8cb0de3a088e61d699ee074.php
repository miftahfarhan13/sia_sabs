<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="font-weight-bold">Jadwal Mengajar</h2>
    <div class="container">
        <div class="row">
            <div class="col-sm">
                <div class="form-group row">
                    <label class="col-sm-3 col-form-label font-weight-bold">Tahun Ajaran</label>

                    <label class="col-sm-5 col-form-label">2019/2020</label>

                </div>
            </div>
        </div>



    </div>

    <div style="max-width:1200px">
        <div class="form-row">
            <div class="col">
                <div class="card">
                    <div class="card-header">Jadwal Mengajar Guru Sekolah</div>
                    <div class="card-body">
                        <table class="table" id="data_table">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Kelas</th>
                                    <th scope="col">Hari</th>
                                    <th scope="col">Jam</th>

                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $jadwal_mengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $jadwal_mengajars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($index+1); ?></th>
                                    <td><?php echo e($jadwal_mengajars->kode_kelas); ?></td>
                                    <td><?php echo e($jadwal_mengajars->hari); ?></td>
                                    <td><?php echo e($jadwal_mengajars->jam); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/jadwal_mengajar_guruSekolah.blade.php ENDPATH**/ ?>