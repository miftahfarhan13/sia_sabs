<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title>SIA | SABS</title>
    <link rel="shortcut icon" href="img/group-6.png">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">


    <!-- Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
        html,
        body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links>a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }

        /* Utility */
        .tombol {
            background-color: #1cc88a;
            border-color: #1cc88a;
            border-radius: 40px;
            padding-left: 40px;
            padding-right: 40px;
        }

        .navbar {
            position: relative;
            z-index: 1;
        }

        .navbar-brand {
            font-size: 32px;
        }

        /* jumbotron */
        .jumbotron {
            background-image: url(img/IMG-20181020-WA0011.jpg);
            background-size: cover;
            text-align: center;
            width: 100%;
            height: 86%;
            bottom: 0;
        }

        .jumbotron .container {
            position: relative;
            z-index: 1;
        }


        .jumbotron .display-4 {
            color: white;
            font-weight: 1000;
            font-size: 40px;
            margin-top: 200px;
            margin-bottom: 30px;
        }

        .jumbotron::after {
            content: '';
            display: block;
            width: 100%;
            height: 100%;
            position: absolute;
            bottom: 0;
            background-image: linear-gradient(to top, rgba(0, 0, 0, 1), rgba(0, 0, 0, 0));
        }


        /* DESKTOP VERSION */
        @media (min-width: 992px) {

            .navbar-brand,
            .nav-link {
                color: white !important;
                text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.7);
                font-weight: 500;
            }

            .nav-link:hover::after {
                content: '';
                display: block;
                border-bottom: 3px solid #006600;
                width: 50%;
                margin: auto;
                padding-bottom: 5px;
                margin-bottom: -8px;
            }

            .jumbotron {
                margin-top: -75px;
                height: 94.5%;
            }

            .jumbotron .display-4 {
                font-size: 62px;
            }

        }

    </style>
</head>

<body>
    <!-- awal navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <img src="img/logo-home.png" class="navbar-brand" href="" width="130px" height="70px" alt="logo">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">

        </div>
    </nav>

    <!-- akhir navbar -->

    <!-- jumbtron -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Sistem Informasi Akademik <br> Sulthon Aulia Boarding School</h1>
            <p class="lead" style="color:white; text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.7);">Selamat Datang!</p>
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a class="nav-item btn btn-success tombol" href="<?php echo e(url('/home')); ?>">Home <span
                    class="sr-only">(current)</span></a>
            <?php else: ?>
            <a class="btn btn-success tombol" href="<?php echo e(route('login')); ?>" style="font-weight: 1000;">Login</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <!-- akhir jumbotron -->

    <!-- <div class="flex-center position-ref full-height">
        <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('/home')); ?>">Home</a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">Login</a>

            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>">Register</a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>


    </div> -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/welcome.blade.php ENDPATH**/ ?>