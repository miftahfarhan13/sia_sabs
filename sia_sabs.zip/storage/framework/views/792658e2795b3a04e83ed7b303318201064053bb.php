<?php $__env->startSection('content'); ?>

<head>
    <title>Home</title>
    <link rel="shortcut icon" href="img/group-6.png">

    <style>
        .card-body-icon {
            position: absolute;
            z-index: 0;
            top: 25px;
            right: 4px;
            opacity: 0.4;
            font-size: 90px;
        }

    </style>
</head>

<body>
    <div>
        <h3 class="font-weight-bold"><i class="fa fa-tachometer-alt mr-4"></i>Dashboard</h3>
        <hr>
        <h4 class="font-weight-bold">Selamat Datang!</h4>
        <div style="max-width: 400px;">
            <div class="alert alert-primary" role="alert">
                <label class="font-weight-bold" style="font-size: 20px;"><?php echo e(Auth::user()->name); ?></label>
                <br>
                <p class="font-weight-bold" style="color: green; font-size:20px;"><?php echo e(Auth::user()->id_user); ?></p>
                <hr>

                <?php if(Auth::user()->role == 'Siswa'): ?>
                <div class="row">
                    <p class="ml-3">Anda sebagai : </p>&ensp;
                    <p class="font-weight-bold"><?php echo e(Auth::user()->role); ?></p>
                </div>

                <div class="row">
                    <p class="ml-3">Kelas Sekolah : </p>&ensp;
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_kelas); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="row">
                    <p class="ml-3">Kelas Asrama : </p>&ensp;
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_sub_kelas); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Gedung : </p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_gedung); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Jenis Kelamin : </p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->jenis_kelamin); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Tanggal Lahir :</p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->tanggal_lahir); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'Orang Tua'): ?>
                <div class="row">
                    <p class="ml-3">Anda sebagai : </p>&ensp;

                    <p class="font-weight-bold"><?php echo e(Auth::user()->role); ?></p>

                </div>

                <p>Data Anak Anda</p>

                <div class="row">
                    <p class="ml-3">Nama Anak : </p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_siswa); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Kelas Sekolah : </p>&ensp;
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_kelas); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="row">
                    <p class="ml-3">Kelas Asrama : </p>&ensp;
                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_sub_kelas); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Gedung : </p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->nama_gedung); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Jenis Kelamin : </p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->jenis_kelamin); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row">
                    <p class="ml-3">Tanggal Lahir :</p>&ensp;

                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="font-weight-bold"><?php echo e($siswas->tanggal_lahir); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <?php endif; ?>


                <?php if(Auth::user()->role == 'Guru Sekolah'): ?>
                <div class="row">
                    <p class="ml-3">Anda sebagai : </p>&ensp;
                    <p class="font-weight-bold"><?php echo e(Auth::user()->role); ?></p>

                </div>
                
                <div class="row">
                    <p class="ml-3">Mata Pelajaran : </p>&ensp;
                    
                        <?php $__currentLoopData = $gurusekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gurusekolahs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($gurusekolahs->nama_mata_pelajaran); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="row">
                    <p class="ml-3">Jenis Kelamin : </p>&ensp;
                    
                        <?php $__currentLoopData = $gurusekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gurusekolahs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($gurusekolahs->jenis_kelamin); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="row">
                    <p class="ml-3">Tanggal Lahir : </p>&ensp;
                    
                        <?php $__currentLoopData = $gurusekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gurusekolahs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($gurusekolahs->tanggal_lahir); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <?php endif; ?>

                <?php if(Auth::user()->role == 'Guru Asrama'): ?>
                <div class="row">
                    <p class="ml-3">Anda sebagai : </p>&ensp;
                    <p class="font-weight-bold"><?php echo e(Auth::user()->role); ?></p>

                </div>
                
                <div class="row">
                    <p class="ml-3">Gedung : </p>&ensp;
                    
                        <?php $__currentLoopData = $guruasrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guruasramas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($guruasramas->nama_gedung); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="row">
                    <p class="ml-3">Jenis Kelamin : </p>&ensp;
                    
                        <?php $__currentLoopData = $guruasrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guruasramas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($guruasramas->jenis_kelamin); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>

                <div class="row">
                    <p class="ml-3">Tanggal Lahir : </p>&ensp;
                    
                        <?php $__currentLoopData = $guruasrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guruasramas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="font-weight-bold"><?php echo e($guruasramas->tanggal_lahir); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <?php endif; ?>

            </div>
        </div>
        <?php if(Auth::user()->role == 'Admin'): ?>
        <div>
            <div class="row">
                <label class="col-sm-2">Info Saat Ini :</label>
            </div>

            <div class="row text-white">
                <div class="card bg-info ml-3 mt-2 " style="width: 18rem;">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-user mr-2"></i>
                        </div>
                        <h5 class="card-title">Jumlah Siswa</h5>
                        <div class="display-4"><?php echo e($siswacount); ?></div>

                    </div>
                </div>

                <div class="card bg-success ml-3 mt-2 " style="width: 18rem;">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-user mr-2"></i>
                        </div>
                        <h5 class="card-title">Jumlah Guru Sekolah</h5>
                        <div class="display-4"><?php echo e($gurusekolahcount); ?></div>

                    </div>
                </div>

                <div class="card bg-danger ml-3 mt-2" style="width: 18rem;">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fa-user mr-2"></i>
                        </div>
                        <h5 class="card-title">Jumlah Guru Asrama</h5>
                        <div class="display-4"><?php echo e($guruasramacount); ?></div>

                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>


    </div>


</body>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sia_sabs\resources\views/home.blade.php ENDPATH**/ ?>