$(document).ready( function () {
    $('.data_table').DataTable();
} );